<?php
/**
 * Please do not edit or add any code in this file without the permission of Saravana Technology Solutions
 *
 * @author    Saravana Technology Solutions
 * @copyright Saravana Technology Solutions
 * @license   http://www.pibblu.in/terms-and-conditions
 * Prestashop version 1.7+
 * skroutzdata 4.1.0
 * Feb 2018
 */

header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Cache-Control: post-check=0, pre-check=0', false);
header('Pragma: no-cache');
header('Location: ../');
exit;
